/*
Theme Name: Lunar
Description: Responsive Coming Soon Template
Author: Erilisdesign
Theme URI: https://preview.erilisdesign.com/html/lunar
Author URI: https://themeforest.net/user/erilisdesign
Version: 2.0.0
License: https://themeforest.net/licenses/standard
*/

/*------------------------------------------------------------------
[Table of contents]

1. Preloader
2. Backgrounds
3. Navigation
4. Masonry Layout
5. Lightbox
6. Slider
7. Countdown
8. Mailchimp
9. Contact Form
10. Home Block - Animations after load
11. Fix Scrolling
12. Photoswipe
-------------------------------------------------------------------*/

(function($) {
	"use strict";

	// Vars
	var $body = $('body'),
		$btnNavigationToggle = $('.nav-toggle'),
		$navigationLinks = $('a.scrollto'),
		$homeBlock = $('.home-block'),
		$contentBlock = $('.content-block'),
		$btnCloseContentBlock = $('.close-content-block'),
		$globalOverlay = $('.global-overlay'),
		$preloader = $('#preloader'),
		preloaderDelay = 1200,
		preloaderFadeOutTime = 500,
		locationHashChanged = true,
		isUserClick,
		target,
		trueMobile;

	function getWindowWidth() {
		return Math.max( $(window).width(), window.innerWidth);
	}

	function getWindowHeight() {
		return Math.max( $(window).height(), window.innerHeight);
	}

	// System Detector
	function lunar_systemDetector() {

		var isMobile = {
			Android: function() {
				return navigator.userAgent.match(/Android/i);
			},
			BlackBerry: function() {
				return navigator.userAgent.match(/BlackBerry/i);
			},
			iOS: function() {
				return navigator.userAgent.match(/iPhone|iPad|iPod/i);
			},
			Opera: function() {
				return navigator.userAgent.match(/Opera Mini/i);
			},
			Windows: function() {
				return navigator.userAgent.match(/IEMobile/i);
			},
			any: function() {
				return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows();
			}
		};

		trueMobile = isMobile.any();

	}

	// [1. Preloader]
	function lunar_preloader() {
		$preloader.delay(preloaderDelay).fadeOut(preloaderFadeOutTime);
	}

	// [2. Backgrounds]
	function lunar_backgrounds() {

		// Image
		var $bgImage = $('.bg-image-holder');
		if($bgImage.length > 0) {
			$bgImage.each(function(){
				var src = $(this).children('img').attr('src');

				$(this).css('background-image','url('+src+')').children('img').hide();
			});
		}

		// Slideshow
		if ($globalOverlay.hasClass('slideshow-background')) {
			$globalOverlay.vegas({
				preload: true,
				timer: false,
				delay: 5000,
				transition: 'fade',
				transitionDuration: 1000,
				slides: [
					{ src: 'assets/images/image-15.jpg' },
					{ src: 'assets/images/image-16.jpg' },
					{ src: 'assets/images/image-17.jpg' },
					{ src: 'assets/images/image-4.jpg' }
				]
			});
		}

		// Slideshow - ZoomOut
		if ($globalOverlay.hasClass('slideshow-zoom-background')) {
			$globalOverlay.vegas({
				preload: true,
				timer: false,
				delay: 7000,
				transition: 'zoomOut',
				transitionDuration: 4000,
				slides: [
					{ src: 'assets/images/image-4.jpg' },
					{ src: 'assets/images/image-16.jpg' },
					{ src: 'assets/images/image-17.jpg' },
					{ src: 'assets/images/image-15.jpg' }
				]
			});
		}

		// Slideshow with Video
		if ($globalOverlay.hasClass('slideshow-video-background')) {
			$globalOverlay.vegas({
				preload: true,
				timer: false,
				delay: 5000,
				transition: 'fade',
				transitionDuration: 1000,
				slides: [
					{ src: 'assets/images/image-15.jpg' },
					{ src: 'demo/video/marine.jpg',
						video: {
							src: [
								'demo/video/marine.mp4',
								'demo/video/marine.webm',
								'demo/video/marine.ogv'
							],
							loop: false,
							mute: true
						}
					},
					{ src: 'assets/images/image-16.jpg' },
					{ src: 'assets/images/image-17.jpg' }
				]
			});
		}

		// Kenburns
		if ($globalOverlay.hasClass('kenburns-background')) {

			var kenburnsDisplayBackdrops = false;
			var kenburnsBackgrounds = [
				{ src: 'assets/images/image-15.jpg', valign: 'center' },
				{ src: 'assets/images/image-14.jpg', valign: 'center' },
				{ src: 'assets/images/image-17.jpg', valign: 'center' }
			];

			$globalOverlay.vegas({
				preload: true,
				transition: 'swirlLeft',
				transitionDuration: 4000,
				timer: false,
				delay: 10000,
				slides: kenburnsBackgrounds,
				walk: function (nb) {
					if (kenburnsDisplayBackdrops === true) {
						var backdrop;

						backdrop = backdrops[nb];
						backdrop.animation = [ 'kenburnsUp', 'kenburnsDown', 'kenburnsLeft', 'kenburnsRight' ];
						backdrop.animationDuration = 20000;
						backdrop.transition = 'fade';
						backdrop.transitionDuration = 1000;

						$globalOverlay
							.vegas('options', 'slides', [ backdrop ])
							.vegas('next');
					}
				}
			});
		}

		// Youtube Video
		if ($('#youtube-background').length > 0) {
			var videos = [
				{videoURL: "iXkJmJa4NvE", showControls:false, containment:'.overlay-video',autoPlay:true, mute:true, startAt:0,opacity:1, loop:true, showYTLogo:false, realfullscreen: true, addRaster:true}
			];

			$('.player').YTPlaylist(videos, true);
		}

		// Youtube Multiple Videos
		if ($('#youtube-multiple-background').length > 0) {

			var videos = [
				{videoURL: "CG20eBusRg0", showControls:false, containment:'.overlay-video',autoPlay:true, mute:true, startAt:0,opacity:1, loop:false, showYTLogo:false, realfullscreen: true, addRaster:true},
				{videoURL: "iXkJmJa4NvE", showControls:false, containment:'.overlay-video',autoPlay:true, mute:true, startAt:0,opacity:1, loop:false, showYTLogo:false, realfullscreen: true, addRaster:true}
			];

			$('.player').YTPlaylist(videos, true);

		}

		// Video Background
		if($body.hasClass('mobile')) {
			$('.video-wrapper').css('display', 'none');
		}

		// Granim
		$('[data-gradient-bg]').each(function(index,element){
			var granimParent = $(this),
				granimID = 'granim-'+index+'',
				colours = granimParent.attr('data-gradient-bg'),
				colours = colours.replace(' ',''),
				colours = colours.replace(/'/g, '"')
				colours = JSON.parse( colours );

			// Add canvas
			granimParent.prepend('<canvas id="'+granimID+'"></canvas>');

			var granimInstance = new Granim({
				element: '#'+granimID,
				name: 'basic-gradient',
				direction: 'left-right', // 'diagonal', 'top-bottom', 'radial'
				opacity: [1, 1],
				isPausedWhenNotInView: true,
				states : {
					"default-state": {
						gradients: colours
					}
				}
			});
		});

	}

	// Parallax Background - Working only for the sections in right block
	function lunar_parallaxBackground() {
		if( getWindowWidth() >= 1200 ){
			$('.content-block-inner').on('scroll', function() {
				parallaxBackground();
			});
		}

		function parallaxBackground(){
			var windowHeight = window.innerHeight || document.documentElement.clientHeight,
				scrollTop = Math.max(window.pageYOffset, document.documentElement.scrollTop, document.body.scrollTop),
				speedDivider = 0.25;

			$('.parallax-background').each(function() {
				var parallaxElement = $(this),
					parallaxHeight = parallaxElement.outerHeight(),
					parallaxTop = parallaxElement.offset().top,
					parallaxBottom = parallaxTop + parallaxHeight,
					parallaxWrapper = parallaxElement.parents('.parallax-wrapper'),		
					section = parallaxElement.parents('section'),
					sectionHeight = parallaxElement.parents('section').outerHeight(),
					offSetTop = scrollTop + section[0].getBoundingClientRect().top,
					offSetPosition = windowHeight + scrollTop - offSetTop;

				if (offSetPosition > 0 && offSetPosition < (sectionHeight + windowHeight)) {
					var value = ((offSetPosition - windowHeight) * speedDivider);

					if (Math.abs(value) < (parallaxHeight - sectionHeight)) {
						parallaxElement.css({
							"transform" : "translate3d(0px, " + value + "px, 0px)",
							"-webkit-transform" : "translate3d(0px, " + value + "px, 0px)"
						});
					} else {
						parallaxElement.css({
							"transform" : "translate3d(0px, " + parallaxHeight - sectionHeight + "px, 0px)",
							"-webkit-transform" : "translate3d(0px, " + parallaxHeight - sectionHeight + "px, 0px)"
						});
					}
				}
			});
		}
	};

	// [3. Navigation]
	function lunar_navigation() {
		$body.removeClass('has-content-block-open');
		$('.header-nav').css('display', '');

		$btnNavigationToggle.off('click');
		$btnNavigationToggle.on('click', function(e) {
			e.preventDefault();

			if( getWindowWidth() >= 1200 )
				return true;

			if( !$(this).hasClass('open') ){
				$(this).addClass('open');
				$('.header-nav').slideDown(500);
			} else {
				$(this).removeClass('open');
				$('.header-nav').slideUp(500);
			}
		});

		$navigationLinks.off('click');
		$navigationLinks.on('click', function(e) {
			if (this.hash !== '') {
				if( locationHashChanged === true ){
					e.preventDefault();
				}

				var hash = this.hash;

				if( getWindowWidth() >= 1200 ){
					isUserClick = true;

					if( $(hash).parents('.home-block').length > 0 ){
						$body.removeClass('has-content-block-open');
						updateNav(hash);
						return;
					}

					if( !$(hash).parents('.content-block').length > 0 )
						return;

					if( !$body.hasClass('has-content-block-open') ){
						$body.addClass('has-content-block-open');
					}

					var offset = document.querySelector(hash).offsetTop;
					$contentBlock.find('.content-block-inner').animate({
						scrollTop: offset
					}, 800);

					updateNav(hash);

					isUserClick = false;
				} else {
					if( $(hash).length > 0 )
						$(window).scrollTop( $(hash).offset().top );
				}
			}
		});

		$btnCloseContentBlock.off('click');
		$btnCloseContentBlock.on('click', function(e) {
			e.preventDefault();

			if( getWindowWidth() >= 1200 ){
				$body.removeClass('has-content-block-open');
				updateNav('#home');
				setTimeout(function(){
					$contentBlock.find('.content-block-inner').scrollTop(0);
				}, 500);
			}
		});

		// Location Hash Changed - Back button trigers animation
		if( locationHashChanged === true ){
			window.onhashchange = lunar_locationHashChanged;
		}

		function locationHashChanged() {
			var hash = location.hash;

			if( getWindowWidth() >= 1200 ){
				if( $(hash).parents('.home-block').length > 0 ){
					$body.removeClass('has-content-block-open');
					updateNav(hash);
					return;
				}

				if( !$(hash).parents('.content-block').length > 0 )
					return;

				if( !$body.hasClass('has-content-block-open') ){
					$body.addClass('has-content-block-open');
				}

				var offset = document.querySelector(hash).offsetTop;
				$contentBlock.find('.content-block-inner').animate({
					scrollTop: offset
				}, 800);

				updateNav(hash);
			} else {
				if( $(hash).length > 0 )
					$(window).scrollTop( $(hash).offset().top );
			}
		}

	}

	// On scroll navigation - Working only for the sections in right block
	function lunar_onScrollNav() {
		if( getWindowWidth() >= 1200 ){
			var lastScrollTop = $('.content-block-inner').scrollTop();

			if( isUserClick === true )
				return true;

			$('.content-block-inner').on('scroll', function(e) {
				var windowHeight = window.innerHeight || document.documentElement.clientHeight,
					scrollTop = Math.max( document.querySelector('.content-block-inner').scrollTop, $('.content-block-inner').scrollTop() ),
					bottomWindow = scrollTop + windowHeight,
					delta = windowHeight * 0.2;

				if( lastScrollTop > scrollTop ){			
					delta = -windowHeight * 0.2;
				} else {
					delta = windowHeight * 0.2;
				}

				$('.content-block section').each(function() {
					if( $(this).attr('id') == '' || !$(this).attr('id') )
						return true;

					var section = $(this),
						sectionHeight = section.outerHeight(),
						offSetTop = scrollTop + section[0].getBoundingClientRect().top,
						offSetPosition = windowHeight + scrollTop - offSetTop;

					if ( delta < 0 ) {
						if (offSetPosition + delta > 0 && offSetPosition < (sectionHeight + windowHeight - delta)) {
							var value = ((offSetPosition - windowHeight) + delta);
							var activeSection = '#' + section.attr('id');
							updateNav(activeSection);
						}
					} else if ( delta > 0 ) {
						if (offSetPosition - delta > 0 && offSetPosition < (sectionHeight + windowHeight + delta)) {
							var value = ((offSetPosition - windowHeight) + delta);
							var activeSection = '#' + section.attr('id');
							updateNav(activeSection);
						}
					}

					lastScrollTop = $('.content-block-inner').scrollTop();
				});
			});
		}
	};

	function updateNav(activeSection) {
		if( !( getWindowWidth() >= 1200 ) )
			return true;

		if( !$('.header-nav a[href="' + activeSection + '"]').parents('li').hasClass('active') ){
			$('.header-nav li').removeClass('active');
			$('.header-nav a[href="' + activeSection + '"]').parents('li').addClass('active');
		}
	};

	// [4. Masonry Layout]
	function lunar_masonryLayout() {
		var $isotopeContainer = $('.isotope-container');

		if ($isotopeContainer.length > 0) {
			var $columnWidth = $isotopeContainer.data('column-width');

			if($columnWidth == null){
				var $columnWidth = '.isotope-item';
			}

			$isotopeContainer.isotope({
				filter: '*',
				animationEngine: 'best-available',
				resizable: false,
				itemSelector : '.isotope-item',
				masonry: {
					columnWidth: $columnWidth
				},
				animationOptions: {
					duration: 750,
					easing: 'linear',
					queue: false
				}
			});
		}

		$('nav.isotope-filter ul a').on('click', function() {
			var selector = $(this).attr('data-filter');
			$isotopeContainer.isotope({ filter: selector });
			$('nav.isotope-filter ul a').removeClass('active');
			$(this).addClass('active');
			return false;
		});

	}

	// [5. Lightbox]
	function lunar_lightbox() {

		$('.mfp-image').magnificPopup({
			type:'image',
			closeMarkup: '<button title="%title%" type="button" class="mfp-close"><i class="ion-android-close"></i></button>',
			removalDelay: 300,
			mainClass: 'mfp-fade'
		});
		
		$('.mfp-gallery').each(function() {
			$(this).magnificPopup({
				delegate: 'a',
				type: 'image',
				gallery: {
					enabled: true
				},
				closeMarkup: '<button title="%title%" type="button" class="mfp-close"><i class="ion-android-close"></i></button>',
				removalDelay: 300,
				mainClass: 'mfp-fade'
			});
		});
		
		$('.mfp-iframe').magnificPopup({
			type: 'iframe',
			iframe: {
				patterns: {
					youtube: {
						index: 'youtube.com/',
						id: 'v=',
						src: '//www.youtube.com/embed/%id%?autoplay=1' // URL that will be set as a source for iframe.
					},
					vimeo: {
						index: 'vimeo.com/',
						id: '/',
						src: '//player.vimeo.com/video/%id%?autoplay=1'
					},
					gmaps: {
						index: '//maps.google.',
						src: '%id%&output=embed'
					}
				},
				srcAction: 'iframe_src'
			},
			closeMarkup: '<button title="%title%" type="button" class="mfp-close"><i class="ion-android-close"></i></button>',
			removalDelay: 300,
			mainClass: 'mfp-fade'
		});
		
		$('.mfp-ajax').magnificPopup({
			type: 'ajax',
			ajax: {
				settings: null,
				cursor: 'mfp-ajax-cur',
				tError: '<a href="%url%">The content</a> could not be loaded.'
			},
			midClick: true,
			closeMarkup: '<button title="%title%" type="button" class="mfp-close"><i class="ion-android-close"></i></button>',
			removalDelay: 300,
			mainClass: 'mfp-fade',
			callbacks: {
				ajaxContentAdded: function(mfpResponse) {
					lunar_slider();
				}
			}
		});
		
		$('.open-popup-link').magnificPopup({
			type: 'inline',
			midClick: true,
			closeMarkup: '<button title="%title%" type="button" class="mfp-close"><i class="ion-android-close"></i></button>',
			removalDelay: 300,
			mainClass: 'mfp-fade'
		});
	}

	// [6. Slider]
	function lunar_slider() {
		var $slider = $('.slider');

		if($slider.length > 0){
			if( !$slider.hasClass('slick-initialized') ){
				$slider.slick({
					slidesToShow: 1,
					infinite: true,
					nextArrow: '<button type="button" class="slick-next"><i class="fas fa-angle-right"></i></button>',
					prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-angle-left"></i></button>'
				});
			}

			if( !( getWindowWidth() >= 576 ) ){
				if( $slider.hasClass('slick-initialized') && $slider.hasClass('unslick-sm') ){
					$slider.slick('unslick');
				}
			}

			if( !( getWindowWidth() >= 768 ) ){
				if( $slider.hasClass('slick-initialized') && $slider.hasClass('unslick-md') ){
					$slider.slick('unslick');
				}
			}

			if( !( getWindowWidth() >= 992 ) ){
				if( $slider.hasClass('slick-initialized') && $slider.hasClass('unslick-lg') ){
					$slider.slick('unslick');
				}
			}

			if( !( getWindowWidth() >= 1200 ) ){
				if( $slider.hasClass('slick-initialized') && $slider.hasClass('unslick-xl') ){
					$slider.slick('unslick');
				}
			}

		}
	}

	// [7. Countdown]
	function lunar_countdown() {
		var countdown = $('.countdown[data-countdown]');

		if (countdown.length > 0) {
			countdown.each(function() {
				var $countdown = $(this),
					finalDate = $countdown.data('countdown');
				$countdown.countdown(finalDate, function(event) {
					$countdown.html(event.strftime(
						'<div class="countdown-container row"><div class="countdown-item col-6 col-sm"><div class="number">%-D</div><span>Day%!d</span></div><div class="countdown-item col-6 col-sm"><div class="number">%H</div><span>Hours</span></div><div class="countdown-item col-6 col-sm"><div class="number">%M</div><span>Minutes</span></div><div class="countdown-item col-6 col-sm"><div class="number">%S</div><span>Seconds</span></div></div>'
					));
				});
			});
		}
	}

	// [8. Mailchimp]
	function lunar_mailchimp() {
		var subscribeForm = $('.subscribe-form');
		if( subscribeForm.length < 1 ){ return true; }

		subscribeForm.each( function(){
			var el = $(this),
				elResult = el.find('.subscribe-form-result');

			el.find('form').validate({
				submitHandler: function(form) {
					elResult.fadeOut( 500 );

					$(form).ajaxSubmit({
						target: elResult,
						dataType: 'json',
						resetForm: true,
						success: function( data ) {
							elResult.html( data.message ).fadeIn( 500 );
							if( data.alert != 'error' ) {
								$(form).clearForm();
								setTimeout(function(){
									elResult.fadeOut( 500 );
								}, 5000);
							};
						}
					});
				}
			});

		});
	}

	// [9. Contact Form]
	function lunar_contactForm() {
		var contactForm = $('.contact-form');
		if( contactForm.length < 1 ){ return true; }

		contactForm.each( function(){
			var el = $(this),
				elResult = el.find('.contact-form-result');

			el.find('form').validate({
				submitHandler: function(form) {
					elResult.fadeOut( 500 );

					$(form).ajaxSubmit({
						target: elResult,
						dataType: 'json',
						success: function( data ) {
							elResult.html( data.message ).fadeIn( 500 );
							if( data.alert != 'error' ) {
								$(form).clearForm();
								setTimeout(function(){
									elResult.fadeOut( 500 );
								}, 5000);
							};
						}
					});
				}
			});

		});
	}

	// [10. Home Block - Animations after load]
	function lunar_animationsAfterLoad() {
		if( !$body.hasClass('mobile') && $html.hasClass('cssanimations') ) {
			if( !$('.home-block .animated').length > 0)
				return;

			$('.home-block .animated').each( function() {
				var elem = $(this);
				if ( !elem.hasClass('visible') ) {
					var animationDelay = elem.data('animation-delay'),
						animation = elem.data('animation');
					if ( animationDelay ) {
						setTimeout(function(){
							elem.addClass( animation + " visible" );
						}, animationDelay);
					} else {
						elem.addClass( animation + " visible" );
					}
				}
			});
		}
	}

	// [11. Fix Scrolling]
	function lunar_fixScrolling() {
		// Fix scrolling when mouse is over another element
		if( getWindowWidth() >= 1200 ){
			var outerDiv = $('.content-block-inner');

			$(document).on( 'mouseenter', '.site-header,.home-block,.global-overlay', function() {
				if( $body.hasClass('has-content-block-open') ){
					$(document).on( 'mousewheel DOMMouseScroll', function(e){
						if ( e.preventDefault ) {
							e.preventDefault();
						}
						e.stopPropagation();

						var delta = ( e.originalEvent.wheelDelta || -e.originalEvent.detail );

						if ( delta > 0 && delta < 100 )
							delta = 100;
						if (delta < 0 && delta > -100 )
							delta = -100;

						outerDiv.scrollTop( outerDiv.scrollTop() - delta );
					});
				}
			});

			$(document).on( 'mouseleave', '.site-header,.home-block,.global-overlay', function() {
				$(document).off('mousewheel DOMMouseScroll');
			});

			// Add Keyboard support - up/down
			$(document).on( 'keydown', function(e) {
				if( $body.hasClass('has-content-block-open') ){
					if ( e.which == 40 ) {
						outerDiv.scrollTop( outerDiv.scrollTop() - -20 );
					} else if ( e.which == 38 ) {
						outerDiv.scrollTop( outerDiv.scrollTop() - 20 );
					}
				}
			});

		} else {
			$(document).off( 'mouseenter mouseleave', '.site-header,.home-block,.global-overlay');
		}
	}
	lunar_fixScrolling();
	
	// [12. Photoswipe]
	function lunar_photoSwipe() {
		
		var initPhotoSwipeFromDOM = function(gallerySelector) {

			var parseThumbnailElements = function(el) {
				var thumbElements = el.childNodes,
					numNodes = thumbElements.length,
					items = [],
					articleEl,
					childElements,
					linkEl,
					size,
					item;

				for(var i = 0; i < numNodes; i++) {
					
					articleEl = thumbElements[i];

					// include only element nodes 
					if(articleEl.nodeType !== 1) {
						continue;
					}

					linkEl = articleEl.children[0].children[0];
					size = linkEl.getAttribute('data-size').split('x');

					// create slide object
					item = {
						src: linkEl.getAttribute('href'),
						w: parseInt(size[0], 10),
						h: parseInt(size[1], 10)
					};

					item.title = true;			
					item.el = articleEl; // save link to element for getThumbBoundsFn

					if(articleEl.children[0].children.length > 1) {
						item.details = articleEl.children[0].children[1].outerHTML; // caption (contents of figure)
					}

					if(linkEl.children.length > 0) {
						item.msrc = linkEl.children[0].getAttribute('src'); // thumbnail url
					}

					// original image
					item.o = {
						src: item.src,
						w: item.w,
						h: item.h
					};

					items.push(item);
				}

				return items;
			};

			// find nearest parent element
			var closest = function closest(el, fn) {
				return el && ( fn(el) ? el : closest(el.parentNode, fn) );
			};

			var onThumbnailsClick = function(e) {
				e = e || window.event;
				e.preventDefault ? e.preventDefault() : e.returnValue = false;

				var eTarget = e.target || e.srcElement;

				var clickedListItem = closest(eTarget, function(el) {
					return el.tagName === 'ARTICLE';
				});

				if(!clickedListItem) {
					return;
				}

				var clickedGallery = clickedListItem.parentNode,
					childNodes = clickedListItem.parentNode.childNodes,
					numChildNodes = childNodes.length,
					nodeIndex = 0,
					index;

				for (var i = 0; i < numChildNodes; i++) {
					if(childNodes[i].nodeType !== 1) { 
						continue;
					}

					if(childNodes[i] === clickedListItem) {
						index = nodeIndex;
						break;
					}
					nodeIndex++;
				}

				if(index >= 0) {
					openPhotoSwipe( index, clickedGallery );
				}
				return false;
			};

			var photoswipeParseHash = function() {
				var hash = window.location.hash.substring(1),
				params = {};

				if(hash.length < 5) { // pid=1
					return params;
				}

				var vars = hash.split('&');
				for (var i = 0; i < vars.length; i++) {
					if(!vars[i]) {
						continue;
					}
					var pair = vars[i].split('=');
					if(pair.length < 2) {
						continue;
					}
					params[pair[0]] = pair[1];
				}

				if(params.gid) {
					params.gid = parseInt(params.gid, 10);
				}

				return params;
			};

			var openPhotoSwipe = function(index, galleryElement, disableAnimation) {
				var pswpElement = document.querySelectorAll('.pswp')[0],
					gallery,
					options,
					items;

				items = parseThumbnailElements(galleryElement);

				// Define options
				options = {
					
					// Core
					index: index,
					getThumbBoundsFn: function(index) {
						// See Options->getThumbBoundsFn section of docs for more info
						var thumbnail = items[index].el.children[0],
							pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
							rect = thumbnail.getBoundingClientRect();

						return {x:rect.left, y:rect.top + pageYScroll, w:rect.width};
					},
					bgOpacity: 0.97,
					loop: true,
					closeOnScroll: false,
					history: false,
					galleryUID: galleryElement.getAttribute('data-pswp-uid'),
					focus: false,
					modal: false,
					
					// UI
					addCaptionHTMLFn: function(item, captionEl, isFake) {
						if(!item.details) {
							captionEl.children[0].innerText = '';
							return false;
						}
						captionEl.children[0].innerHTML = item.details;
						return true;
					},

					// Buttons/elements
					closeEl: true,
					captionEl: true,
					fullscreenEl: true,
					zoomEl: true,
					shareEl: true,
					counterEl: true,
					arrowEl: true,
					preloaderEl: true
				};

				// Exit if index not found
				if( isNaN(options.index) ) {
					return;
				}

				if(disableAnimation) {
					options.showAnimationDuration = 0;
				}

				// Pass data to PhotoSwipe and initialize it
				gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options);

				// see: http://photoswipe.com/documentation/responsive-images.html
				var realViewportWidth,
					useLargeImages = false,
					firstResize = true,
					imageSrcWillChange;

				gallery.listen('beforeResize', function() {

					var dpiRatio = window.devicePixelRatio ? window.devicePixelRatio : 1;
					dpiRatio = Math.min(dpiRatio, 2.5);
					realViewportWidth = gallery.viewportSize.x * dpiRatio;

					if(realViewportWidth >= 1200 || (!gallery.likelyTouchDevice && realViewportWidth > 800) || screen.width > 1200 ) {
						if(!useLargeImages) {
							useLargeImages = true;
							imageSrcWillChange = true;
						}
					} else {
						if(useLargeImages) {
							useLargeImages = false;
							imageSrcWillChange = true;
						}
					}

					if(imageSrcWillChange && !firstResize) {
						gallery.invalidateCurrItems();
					}

					if(firstResize) {
						firstResize = false;
					}

					imageSrcWillChange = false;

				});

				gallery.listen('gettingData', function(index, item) {
					if( useLargeImages ) {
						item.src = item.o.src;
						item.w = item.o.w;
						item.h = item.o.h;
					} else {
						item.src = item.o.src;
						item.w = item.o.w;
						item.h = item.o.h;
					}
				});

				gallery.init();
			};

			// select all gallery elements
			var galleryElements = document.querySelectorAll( gallerySelector );
			for(var i = 0, l = galleryElements.length; i < l; i++) {
				galleryElements[i].setAttribute('data-pswp-uid', i+1);
				galleryElements[i].onclick = onThumbnailsClick;
			}

			// Parse URL and open gallery if it contains #&pid=3&gid=1
			var hashData = photoswipeParseHash();
			if(hashData.pid && hashData.gid) {
				openPhotoSwipe( hashData.pid, galleryElements[ hashData.gid - 1 ], true, true );
			}
		};

		initPhotoSwipeFromDOM('.portfolio-gallery');
		
	}

	// document.ready function
	jQuery(document).ready(function($) {
		$('html, body').scrollTop(0);
		lunar_backgrounds();
		lunar_navigation();
		lunar_onScrollNav();
		lunar_lightbox();
		lunar_slider();
		lunar_countdown();
		lunar_mailchimp();
		lunar_contactForm();
		lunar_parallaxBackground();
		lunar_photoSwipe();
	});

	// window load function
	$(window).on('load', function() {
		$(window).scroll();
		lunar_preloader();
		lunar_masonryLayout();
	});

	// window.resize function
	$(window).on('resize', function() {
		lunar_navigation();
		lunar_onScrollNav();
		lunar_masonryLayout();
		lunar_slider();
		lunar_parallaxBackground();
		lunar_fixScrolling();
	});

})(jQuery);